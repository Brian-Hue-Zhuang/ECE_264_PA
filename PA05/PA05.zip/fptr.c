#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "answer05.h"

void scan_tree_node(FILE *fptr, tree_node *tree, bFILE *bfp);

FILE *file_open_input(char *filename)
{
  FILE *fptr;
  fptr = fopen(filename, "rb");
  if(!fptr)
  {
    fprintf(stderr, "filename invalid\n");
    return NULL;
  }
  return fptr;
}

FILE *file_open_output(char *filename)
{
  FILE *fptr;
  fptr = fopen(filename, "wb");
  if(!fptr)
  { 
    fprintf(stderr, "filename invalid\n");
    return NULL;
  }
  return fptr;
}

bFILE *b_fopen(char *filename, char *mode)
{
  bFILE *bfp = (bFILE *)malloc(sizeof(bFILE));
  if(strcmp(mode, "r") == 0)
  {
    bfp->mode = 0;
  }
  else if(strcmp(mode, "w") == 0)
  {
    bfp->mode = 1;
  }
  bfp->fp = fopen(filename, mode);
  if(!bfp->fp)
  {
    free(bfp);
    return NULL;
  }
  bfp->buffer = 0;
  bfp->bit_index = 0;
  return bfp;
}

void b_fclose(bFILE *bfp)
{
  if(bfp->mode == 1 && bfp->bit_index > 0)
  {
    fwrite(&bfp->buffer, 1, 1, bfp->fp);
  }
  fclose(bfp->fp);
  free(bfp);
}

int freadbit(bFILE *bfp)
{
  if(bfp->bit_index == 0)
  {
    if(fread(&bfp->buffer, 1, 1, bfp->fp) == 0)
    {
      return -1;
    }
  }
  int bit = (bfp->buffer >> (7 - bfp->bit_index)) & 1;
  bfp->bit_index = (bfp->bit_index + 1) % 8;

  return bit;
}


int fwritebit(bFILE *bfp, int bit)
{
  if(bit != 0 && bit != 1)
  {
    return 0;
  }
  if(bit == 1)
  {
    bfp->buffer |= (1 << (bfp->bit_index));
  }
  bfp->bit_index++;
  
  if(bfp->bit_index == 8)
  {
    fwrite(&bfp->buffer, 1, 1, bfp->fp);
    bfp->buffer = 0;
    bfp->bit_index = 0;
  }
  return 1;
}

long *create_binary_list(FILE *fptr)
{
  if(!fptr)
  {
    return NULL;
  }
  long *out = calloc(256, sizeof(long));
  int letter;
  while((letter = fgetc(fptr)) != EOF)
  {
    out[letter]++;
  }
  return out;
}

int count_unique(tree_node *info) //utilizes linked list
{
  if(!info)
  {
    return 0;
  }
  int unique = 0;
  while(info)
  {
    info = info->next;
    unique++;
  }
  return unique;
}

void pre_order_binary(FILE *fptr, tree_node *tree, int unique, bFILE *bfp) //recursive
{
  if(!(fptr && tree && unique))
  {
    return;
  }
  scan_tree_node(fptr, tree, bfp);
  return;
}

void scan_tree_node(FILE *fptr, tree_node *tree, bFILE *bfp)
{
  if(tree->letter == BLANK_VAL)
  {
    fwritebit(bfp, 0);
    scan_tree_node(fptr, tree->left, bfp);
    scan_tree_node(fptr, tree->right, bfp);
  }
  else
  {
    fwritebit(bfp, 1);
    int bit;
    for(int i = 0; i < 8; i++)
    {
      bit = (tree->letter >> i) & 1;
      fwritebit(bfp, bit); 
    }
  }
  return;
}
